$drives = net use | select -Skip 6 | findstr /v "TSCLIENT"
$drives = $drives[0..($drives.count - 3)] 
$drives = $drives -replace("  +",",") -replace(",$","")

$idx = 1
write-host "{"
write-host " `"data`":[`n"

foreach ($remotedrive in $drives)
{
	$remotedrive_devicename = $remotedrive | % {"$($_.split(',')[1])"}

	$remotedrive_path = $remotedrive | % {"$($_.split(',')[2])"}
    $remotedrive_path = $remotedrive_path.Replace('\','\\')
    $remotedrive_path = $remotedrive_path -replace " $"
	if (!$remotedrive_path ) { $remotedrive_path = "None" }

    	if ($idx -lt $drives.Count)
        {
            $line= "{ `"{#DEVICENAME}`" : `"" + $remotedrive_devicename + "`",`"{#DEVICEREMOTEPATH}`" : `"" + $remotedrive_path +"`"},"
        }
        elseif ($idx -ge $drives.Count)
        {
            $line= "{ `"{#DEVICENAME}`" : `"" + $remotedrive_devicename + "`" ,`"{#DEVICREMOTEPATH}`" : `"" + $remotedrive_path +"`"}"
        }
    	write-host $line
        $idx++;
}

write-host
write-host " ]"
write-host "}"