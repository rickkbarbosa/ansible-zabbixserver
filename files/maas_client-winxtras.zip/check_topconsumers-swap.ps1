#SWAP 
Get-Process | Select-Object -Property Name, ID, PM  | Sort-Object -Property PM -Descending | select -First 5 | ConvertTo-Json -Compress