$metaurl = "http://169.254.169.254/metadata/instance/compute/tags?api-version=2017-08-01&format=text"

function ConvertTo-Json20([object] $item){
    add-type -assembly system.web.extensions
    $ps_js=new-object system.web.script.serialization.javascriptSerializer
    return $ps_js.Serialize($item)
}

if ($PSVersionTable.PSVersion.Major -gt 2)
{
    $vmtags = Invoke-RestMethod -Headers @{"Metadata"="true"} -URI $metaurl -Method get -Timeoutsec 3

    $vmtags -split ';' | ConvertTo-Json -Compress
}
else
{
    $vmtags = New-Object System.Net.WebClient
    $vmtags.Headers.add('Metadata','true')
    $vmtags = $vmtags.DownloadString("$metaurl") -split ';'
    write-host "[ $vmtags ]"

}
 
