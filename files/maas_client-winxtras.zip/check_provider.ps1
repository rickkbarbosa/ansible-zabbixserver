$msmetaurl = "http://169.254.169.254/metadata/instance/compute/vmId?api-version=2017-08-01&format=text"
$awsmetaurl = "http://169.254.169.254/latest/meta-data/instance-id"

$msinstancetypeurl = "http://169.254.169.254/metadata/instance/compute/vmSize?api-version=2017-08-01&format=text"
$awsinstancetypeurl = "http://169.254.169.254/latest/meta-data/instance-type"



Try
{
    $vmid = Invoke-RestMethod -Headers @{"Metadata"="true"} -URI $msmetaurl -Method get -TimeoutSec 3
}
Catch
{
    Try
    {
        $vmid = Invoke-RestMethod -Headers @{"Metadata"="true"} -URI $awsmetaurl -Method get -TimeoutSec 3
        Break
    }
    Catch
    {
        $vmid = $Null
    }
}

If (!$vmid) {
  $instancecloud = "OnPremise"
  $instanceid = "None"
  $instancetype = "NAN"      
} Else {
    #Is Azure?
    $s = '^[0-9|a-z|A-Z]{8}\-([0-9|a-z|A-Z]{4}\-){3}[0-9|a-z|A-Z]{12}'
    $result = $vmid -match $s
    If ($result -eq $True) {
        $instanceid = $vmid
        $instancecloud = "Azure"
        $instancetype = Invoke-RestMethod -Headers @{"Metadata"="true"} -URI $msinstancetypeurl -Method get -TimeoutSec 3
    } Else {
        #Is AWS/Openstack?
        $s = '^i\-.*'
        $result = $vmid -match $s
        If ($result -eq $True) {
            $instancetype = Invoke-RestMethod -Headers @{"Metadata"="true"} -URI $awsinstancetypeurl -Method get -TimeoutSec 3
            #Test if is AWS
            $s = '^i\-[0-9|a-z|A-Z]{17}$'
            $result = $vmid -match $s
            If ($result -eq $True) {
                $instancecloud = "Amazon AWS"
            } Else {
                $instancecloud = "Openstack"   
            }
        } Else {
            $instancecloud = "Other Provider"
            Try
            {
                $instancetype = Invoke-RestMethod -Headers @{"Metadata"="true"} -URI $awsinstancetypeurl -Method get -TimeoutSec 3
            }
            Catch
            {
                $instancetype="NAN"
            }
        }
    }   

}

$data = '{ "data": [ { "HOST_PROVIDER": "' + $instancecloud + '", "HOST_ID": "' + $vmid + '", "HOST_TYPE": "' + $instancetype + '" }]}'

if ($PSVersionTable.PSVersion.Major -gt 2)
{
    $data | ConvertFrom-Json | ConvertTo-Json
}
else
{
    $data
}