#Memory 
Get-Process | Select-Object -Property Name, ID, WS  | Sort-Object -Property WS -Descending | select -First 5 | ConvertTo-Json -Compress